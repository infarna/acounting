from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.renderers import JSONRenderer
from rest_framework.parsers import JSONParser
from dashboard.models import Dashboard, Navigation
from dashboard.serializers import DashboardSerializer, NavigationSerializer
# Create your views here.


@csrf_exempt
def dashboard_items(request):
    """
    List all code snippets, or create a new snippet.
    """
    if request.method == 'GET':
        dashboard = Dashboard.objects.all()
        serializer = DashboardSerializer(dashboard, many=True)
        return JsonResponse(serializer.data, safe=False)
'''
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = DashboardSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
'''


@csrf_exempt
def dashboard_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        dashboard = Dashboard.objects.get(pk=pk)
    except Dashboard.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = DashboardSerializer(dashboard)
        return JsonResponse(serializer.data)
'''
    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)
'''

@csrf_exempt
def navigation_items(request):
    """
    List all code snippets, or create a new snippet.
    """
    if request.method == 'GET':
        navigation = Navigation.objects.all()
        serializer = NavigationSerializer(navigation, many=True)
        return JsonResponse(serializer.data, safe=False)
'''
    elif request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = NavigationSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data, status=201)
        return JsonResponse(serializer.errors, status=400)
'''


@csrf_exempt
def navigation_detail(request, pk):
    """
    Retrieve, update or delete a code snippet.
    """
    try:
        navigation = Navigation.objects.get(pk=pk)
    except Navigation.DoesNotExist:
        return HttpResponse(status=404)

    if request.method == 'GET':
        serializer = NavigationSerializer(navigation)
        return JsonResponse(serializer.data)
'''
    elif request.method == 'PUT':
        data = JSONParser().parse(request)
        serializer = SnippetSerializer(snippet, data=data)
        if serializer.is_valid():
            serializer.save()
            return JsonResponse(serializer.data)
        return JsonResponse(serializer.errors, status=400)

    elif request.method == 'DELETE':
        snippet.delete()
        return HttpResponse(status=204)
'''