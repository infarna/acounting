from rest_framework import serializers
from dashboard.models import Dashboard, Navigation, LANGUAGE_CHOICES, STYLE_CHOICES


class DashboardSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    created = serializers.CharField()
    name = serializers.CharField(required=False, allow_blank=True, max_length=100)
    description = serializers.CharField()
    created_by = serializers.CharField()

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Dashboard.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.name = validated_data.get('name', instance.name)
        instance.created = validated_data.get('created', instance.created)
        instance.description = validated_data.get('description', instance.description)
        instance.created_by = validated_data.get('created_by', instance.created_by)
        instance.save()
        return instance


class NavigationSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    created = serializers.CharField()
    name = serializers.CharField(required=False, allow_blank=True, max_length=100)
    description = serializers.CharField()
    created_by = serializers.CharField()

    def create(self, validated_data):
        """
        Create and return a new `Snippet` instance, given the validated data.
        """
        return Dashboard.objects.create(**validated_data)

    def update(self, instance, validated_data):
        """
        Update and return an existing `Snippet` instance, given the validated data.
        """
        instance.name = validated_data.get('name', instance.name)
        instance.created = validated_data.get('created', instance.created)
        instance.description = validated_data.get('description', instance.description)
        instance.created_by = validated_data.get('created_by', instance.created_by)
        instance.save()
        return instance

