from django.urls import path
from dashboard import views

urlpatterns = [
    path('dashboard/', views.dashboard_items),
    path('dashboard/<int:pk>/', views.dashboard_detail),
    path('navigation/', views.navigation_items),
    path('navigation/<int:pk>/', views.navigation_detail),
]